\# Tubes\_terserah



Repository ini berisi program bot Robocode Tank Royale yang mengimplementasikan algoritma greedy sebagai strategi pengambilan keputusan dalam pertandingan.



\## 1. Penjelasan Singkat Algoritma Greedy



Algoritma greedy adalah strategi penyelesaian masalah dengan memilih keputusan terbaik pada kondisi saat ini. Pada program ini, greedy digunakan untuk menentukan target atau tindakan bot berdasarkan informasi yang diperoleh dari radar.



Terdapat empat bot yang dibuat, yaitu:



1\. \*\*GreedyClosestBot\*\*  

&#x20;  Bot memilih musuh dengan jarak paling dekat sebagai target. Strategi ini menggunakan pendekatan \*\*Greedy by Distance\*\*, yaitu memilih kandidat dengan jarak terkecil dari posisi bot.



2\. \*\*GreedyEnergyBot\*\*  

&#x20;  Bot memilih musuh dengan energi paling rendah sebagai target. Jika terdapat dua musuh dengan energi yang sama, bot memilih musuh yang jaraknya lebih dekat. Strategi ini menggunakan pendekatan \*\*Greedy by Lowest Energy\*\*.



3\. \*\*GreedySurvivalBot\*\*  

&#x20;  Bot memilih musuh terdekat sebagai ancaman utama, kemudian bergerak untuk menjaga jarak aman. Strategi ini menggunakan pendekatan \*\*Greedy by Survival Risk\*\*.



4\. \*\*GreedyMainBot\*\*  

&#x20;  Bot utama menggunakan strategi \*\*Greedy by Opportunity Score\*\*, yaitu memilih target berdasarkan skor gabungan dari jarak musuh, energi musuh, dan kelayakan jarak tembak.



Rumus yang digunakan pada `GreedyMainBot` adalah:



```text

Score(target) = 0.45 × DistanceScore + 0.35 × EnergyScore + 0.20 × RangeScore

```



Target dengan skor tertinggi akan dipilih sebagai target utama pada kondisi saat itu.



\## 2. Requirement Program



Program ini membutuhkan beberapa perangkat lunak berikut:



1\. \*\*Java Runtime Environment / JDK\*\*  

&#x20;  Digunakan untuk menjalankan Robocode Tank Royale GUI.



2\. \*\*.NET SDK 8.0\*\*  

&#x20;  Digunakan untuk melakukan compile/build program bot berbasis C#.



3\. \*\*Robocode Tank Royale GUI 0.30.0\*\*  

&#x20;  Digunakan sebagai arena pertandingan bot.



4\. \*\*Visual Studio Code\*\*  

&#x20;  Digunakan untuk mengedit source code.



Untuk mengecek Java:



```powershell

java -version

```



Untuk mengecek .NET:



```powershell

dotnet --version

```



\## 3. Cara Build dan Menjalankan Program



Masuk ke folder repository:



```powershell

cd C:\\Users\\Natan\\Downloads\\Tubes\_terserah

```



Build bot utama:



```powershell

dotnet build .\\src\\main-bot\\GreedyMainBot\\GreedyMainBot.csproj

```



Build bot alternatif:



```powershell

dotnet build .\\src\\alternative-bots\\GreedyClosestBot\\GreedyClosestBot.csproj

dotnet build .\\src\\alternative-bots\\GreedyEnergyBot\\GreedyEnergyBot.csproj

dotnet build .\\src\\alternative-bots\\GreedySurvivalBot\\GreedySurvivalBot.csproj

```



Jika berhasil, terminal akan menampilkan:



```text

Build succeeded.

0 Error(s)

```



Untuk menjalankan Robocode Tank Royale GUI:



```powershell

java -jar .\\robocode-tankroyale-gui-0.30.0.jar

```



Setelah GUI terbuka:



1\. Pilih menu \*\*Battle\*\*.

2\. Pilih \*\*Start Battle\*\*.

3\. Boot bot yang ingin digunakan.

4\. Tambahkan bot ke daftar peserta battle.

5\. Klik \*\*Start Battle\*\*.



\## 4. Kendala Saat Development



Beberapa kendala yang sempat ditemukan saat development adalah:



1\. \*\*File `.exe` terkunci saat build\*\*  

&#x20;  Hal ini terjadi karena bot masih berjalan di Robocode. Solusinya adalah menghentikan proses bot terlebih dahulu.



```powershell

taskkill /F /IM GreedyMainBot.exe

taskkill /F /IM GreedyClosestBot.exe

taskkill /F /IM GreedyEnergyBot.exe

taskkill /F /IM GreedySurvivalBot.exe

```



Jika Robocode masih berjalan, hentikan proses Java:



```powershell

taskkill /F /IM java.exe

```



2\. \*\*Bot tidak muncul pada Joined Bots\*\*  

&#x20;  Masalah ini biasanya terjadi karena bot belum berhasil di-build atau masih terdapat kesalahan pada file `.cs`, `.json`, atau `.csproj`.



3\. \*\*Kesalahan penulisan sintaks C#\*\*  

&#x20;  Beberapa error muncul karena nama variabel tidak konsisten, kurang tanda titik koma, atau nama class tidak sesuai dengan nama file bot.



\## 5. Author



Kelompok: \*\*terserah\*\*



Anggota:



1\. Natan

2\. Rendi

3\. Arbani



Mata Kuliah: Strategi Algoritma  

Topik: Implementasi Algoritma Greedy pada Robocode Tank Royale

